<br><br>
<form class="js-validation-bootstrap" method="POST" action="#">
<div class="section-container">
    <div class="container">

        <div class="row" style="margin-bottom:500px;">
            
        <div class="col-sm-6 col-sm-offset-3">
            <br><br> <h2 style="color:#0fad00">Booking Successful</h2>
            <!-- <img src="http://osmhotels.com//assets/check-true.jpg"> -->
            <!-- <h3>Dear, Faisal khan</h3> -->
            <p style="font-size:20px;color:#5C5C5C;">Thank you for Booking with Innovative Travel Solutions. Your bookings is currently on reviewed by our agent, expect to have one of our travel consultants to keep in touch with you via phone or email as soon as possible.</p>

        <br><br>
        </div>

            

        </div>
    
    </div>
</div>

